﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Grocery_Shop_Management_System
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        private string username;
        private string password;

        private void adminbtn_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();
            employee.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            username = txTUsername
                .Text;
            password = txtPassword.Text;

            SqlConnection conn = new SqlConnection();
         
            conn.ConnectionString = "Data Source = DESKTOP - D330OC5\\SQLEXPRESS; Initial Catalog = Grocery_Store; Integrated Security = True";
            conn.Open();
            string query = "SELECT * FROM LoginTable "


            SqlCommand command = new SqlCommand(query, conn);
            var reader = command.ExecuteReader();

           



            // Data Source = DESKTOP - D330OC5\SQLEXPRESS; Initial Catalog = Grocery_Store; Integrated Security = True; Trust Server Certificate = True
            if (username == null || password == null)
            {
                MessageBox.Show("Plz enter the information ");
            }
            else if(reader.Read()) {




                MessageBox.Show("LOGIN Successfully");
            item item = new item();
            item.Show();
            this.Hide();
        }

        private void btnCross_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
